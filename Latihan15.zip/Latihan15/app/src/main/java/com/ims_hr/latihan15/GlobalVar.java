package com.ims_hr.latihan15;

public class GlobalVar {

    public static final String EXTRA_HURUF = "extra_huruf";
    public static final String EXTRA_GAMBAR = "extra_gambar";

}
